'''
@author ichaudr

Convert a fasta file holding hiv genomic sequences to a JSON format.

'''

from Bio import SeqIO
from tqdm import tqdm
import json

fasta_file = 'hiv_complete.fasta'
output = 'hiv_complete.json'

#A dictionary holding the info needed to parse out strain information from the sequence id
indexing = {'del':'=', 'accession':4, 'subtype': 0, 'country_code': 1, 'name':3}

output_json = []

with open(fasta_file, 'r') as file:
    for record in tqdm(SeqIO.parse(file, 'fasta')):
        output_json.append({
            'subtype': str(record.id).split(indexing['del'])[indexing['subtype']],
            'accession': str(record.id).split(indexing['del'])[indexing['accession']],
            'country_code': str(record.id).split(indexing['del'])[indexing['country_code']],
            'name': str(record.id).split(indexing['del'])[indexing['name']],
            'sequence': str(record.seq)
        })


with open(output, 'w+') as file:
    json.dump(output_json, file)
